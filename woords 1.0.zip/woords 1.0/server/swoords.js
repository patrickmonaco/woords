// -----------------------------------------------------------------------------------------
// woords.js
// v1.0
// GPM FACTORY
// June 2024
// 
// Woords Server
// triggering word templates 
// usage : node swoords.js
// -----------------------------------------------------------------------------------------
const express = require('express');
const { exec } = require('child_process');
const { spawn } = require('child_process');
const fs = require('fs');
const crypto = require('crypto');

const app = express();
const port = 3000;

function genererateName(longueur) {
    let chaine = '';
    const caracteresPermis = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

    for (let i = 0; i < longueur; i++) {
        const caractereAleatoire = caracteresPermis.charAt(Math.floor(Math.random() * caracteresPermis.length));
        chaine += caractereAleatoire;
    }

    return chaine;
}

// Route GET pour exécuter la commande DOS
app.get('/viewpdf/:config/:pkid?', (req, res) => {
    const config = req.params.config;
    const pkid = req.params.pkid
    let fname = ''
    if (pkid) { p2 = '-i '+pkid;fname = pkid;} else {p2=''; fname = config;}
    console.log("config=" + config)
    // Generates a random name
    const folderName = genererateName(10);
    let cmd = '..\bin\woords.cmd '
    //console.log(folderName);
    
    
    // Build command
    cmd = cmd + " -c" + config + ' -f ' + folderName + p2 + ' -v N';
    console.log(cmd)
    // Exécuter la commande DOS
    exec(cmd, (error, stdout, stderr) => {
        if (error) {
            console.error(`Erreur lors de l'exécution de la commande DOS: ${error.message}`);
            return;
        }
        if (stderr) {
            console.error(`Erreur lors de l'exécution de la commande DOS: ${stderr}`);
            return;
        }

        console.log(`Résultat de la commande DOS: ${stdout}`);

        // Attendre la présence du fichier PDF dans le répertoire spécifié
        const filePath = '../pdf/' + folderName + '/' + fname + '.pdf';
        const logFile = '../pdf/' + folderName + '/' + 'error.log';
        console.log('Waiting incoming ' + fname + '.pdf file ...');
        const interval = setInterval(() => {
            if (fs.existsSync(filePath)) {
                // Lire le contenu du fichier PDF
                const pdfContent = fs.readFileSync(filePath);
                // Envoyer le contenu du fichier PDF dans la réponse
                res.setHeader('Content-Type', 'application/pdf');
                res.send(pdfContent);
                clearInterval(interval); // Arrêter l'attente une fois que le fichier PDF est trouvé
            }
            /*
            if (fs.existsSync(filePath)) {
                // Lire le contenu du fichier PDF
                const pdfContent = fs.readFileSync(logFile);
                // Envoyer le contenu du fichier Log dans la réponse
                res.setHeader('Content-Type', 'application/txt');
                res.send(pdfContent);
                clearInterval(interval); // Arrêter l'attente une fois que le fichier PDF est trouvé
            }
            */
        }, 1000); // Vérifier toutes les secondes
        console.log(`Finished`)
    });
});

// Route GET pour exécuter la commande DOS
app.get('/pdfsync/:config/:pkid?', (req, res) => {
    const config = req.params.config;
    const pkid = req.params.pkid
    let fname = ''
    if (pkid) { p2 = ':i:'+pkid;fname = pkid;} else {p2=''; fname = config;}
    console.log("config=" + config)
    // Generates a random name
    const folderName = genererateName(10);
    let cmd = '..\bin\woords.cmd '
    //console.log(folderName);
    
    // Build command
    cmd = cmd + " c:" + config + ':f:' + folderName + p2 + ' -v N';
    console.log(cmd)
    // Exécuter la commande DOS
    
    exec(cmd, (error, stdout, stderr) => {
        if (error) {
            console.error(`Erreur lors de l'exécution de la commande DOS: ${error.message}`);
            return;
        }
        if (stderr) {
            console.error(`Erreur lors de l'exécution de la commande DOS: ${stderr}`);
            return;
        }

        console.log(`Résultat de la commande DOS: ${stdout}`);

        console.log(`Finished`)
    });
});


// Route GET pour exécuter la commande DOS
app.get('/pdf/:config/:pkid?', (req, res) => {
    
    const config = req.params.config;
    const pkid = req.params.pkid
    let fname = ''
    if (pkid) { p2 = '-i '+pkid;fname = pkid;} else {p2=''; fname = config;}
    console.log("config=" + config)
    // Generates a random name
    const folderName = genererateName(10);
    let cmd = '..\bin\woords.cmd '
    
    // Build command
    //cmd = cmd + " c:" + config + ':f:' + folderName + p2;
    console.log(cmd + " -c " + config + ' -f ' + folderName + p2)
   //const args = 'c:' + config + ':f:' + folderName + p2;
    const args = '-c ' + config + '-f ' + folderName + p2 + ' -v N';
    
    //const args = 'azerty'
    const arguments = [args];

    //const processus = spawn(cmd, arguments);
    const processus = spawn(cmd, arguments);
    //res.setHeader('Content-Type', 'application/html');
    res.send('<h3>Request for ' + pkid  + ' has been submitted. Check the logs</h3>');           
    processus.stdout.on('data', (data) => {
      console.log(`Données du processus : ${data}`);
    });

    processus.stderr.on('data', (data) => {
      console.error(`Erreur du processus : ${data}`);
    });

    processus.on('close', (code) => {
      console.log(`Processus fils terminé avec le code de sortie ${code}`);
    });
});


// Démarrer le serveur
app.listen(port, () => {
    console.log(`Serveur démarré sur le port ${port}`);
    
});